<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Plugin\Block;

use Magento\Framework\Data\Tree\NodeFactory;

class TopMenu
{
    /**
     * @var \Magezon\Blog\Model\ResourceModel\Category\Collection
     */
    protected $_collection;

    /**
     * @var array
     */
    protected $_categories;

    /**
     * @var array
     */
    protected $_postCatgoryList;

    /**
     * @var NodeFactory
     */
    protected $nodeFactory;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory
     */
    protected $postCollectionFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context             $context               
     * @param \Magento\Framework\Registry                                  $registry              
     * @param NodeFactory                                                  $nodeFactory           
     * @param \Magento\Framework\App\ResourceConnection                    $resource              
     * @param \Magezon\Blog\Helper\Data                                    $dataHelper            
     * @param \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory $collectionFactory     
     * @param \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory     $postCollectionFactory 
     * @param array                                                        $data                  
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        NodeFactory $nodeFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magezon\Blog\Helper\Data $dataHelper,
        \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory $collectionFactory,
        \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
        array $data = []
    ) {
        $this->nodeFactory           = $nodeFactory;
        $this->resource              = $resource;
        $this->dataHelper            = $dataHelper;
        $this->collectionFactory     = $collectionFactory;
        $this->postCollectionFactory = $postCollectionFactory;
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Category\Collection
     */
    public function getCollection()
    {
        if ($this->_collection === NULL) {
            $collection = $this->collectionFactory->create();
            $collection->prepareCollection();
            $collection->addFieldToFilter('include_in_menu', 1);
            $collection->setOrder('position', 'ASC');
            $this->_collection = $collection;
        }
        return $this->_collection;
    }

    /**
     * @return array
     */
    public function getPostCategoryList()
    {
        if ($this->_postCatgoryList === NULL) {
            $ids = $this->getCollection()->getAllIds();
            $connection = $this->resource->getConnection();
            $select = $connection->select()->from($this->resource->getTableName('mgz_blog_category_post'))->where('category_id IN (?)', $ids);
            $result = $connection->fetchAll($select);

            $postCollection = $this->postCollectionFactory->create();
            $postCollection->getSelect()->joinLeft(
                ['mbcp' => $this->resource->getTableName('mgz_blog_category_post')],
                'main_table.post_id = mbcp.post_id',
                []
            )->group('main_table.post_id');
            $postCollection->prepareCollection();

            foreach ($result as $k => $row) { 
                if (!$postCollection->getItemById($row['post_id'])) {
                    unset($result[k]);
                }
            }
            $this->_postCatgoryList = array_values($result);
        }
        return $this->_postCatgoryList;
    }

    /**
     * @param  \Magezon\Blog\Model\Categor $category 
     * @return int           
     */
    public function getPostCount(\Magezon\Blog\Model\Category $category)
    {
        $count = 0;
        $list = $this->getPostCategoryList();
        if ($list) {
            foreach ($list as $_row) {
                if ($_row['category_id'] == $category->getId()) $count++;
            }
        }
        return $count;
    }

    /**
     * @return array
     */
    public function getCategories()
    {
        if ($this->_categories === NULL) {
            $showProductCount = $this->showPostCount();
            $categories = [];
            $ids = $this->getCollection()->getAllIds();

            $items = $this->getCollection()->getItems();
            foreach ($items as $k => $_category) {
                if (!$_category->getParentId()) {
                    $categories[] = $_category;
                    unset($items[$k]);
                }
                if ($showProductCount) {
                    $_category->setPostCount($this->getPostCount($_category));
                }
            }
            $this->_items = $items;
            foreach ($categories as &$_category) {
                $children = $this->prepareList($_category);
                if ($children) $_category->setChildren($children);
            }
            $this->_categories = $categories;
        }
        return $this->_categories;
    }

    /**
     * @param  \Magezon\Blog\Model\Category $category
     * @return array
     */
    private function prepareList(\Magezon\Blog\Model\Category $category)
    {
        $childrens = [];
        foreach ($this->_items as $k => $_category) {
            if ($_category->getParentId() == $category->getId()) {
                $hasChildren = false;
                $children = $_category;
                foreach ($this->_items as $_category2) {
                    if ($_category2->getParentId() == $_category->getId()) {
                        $hasChildren = true;
                        break;
                    }
                }
                if ($hasChildren && ($_children = $this->prepareList($children))) {
                    $children->setChildren($_children);
                }
                $childrens[] = $children;
            }
        }
        return $childrens;
    }

    public function prepareMenu($node)
    {
        $html = '';
        $categories = $this->getCategories();
        foreach ($categories as $category) {
            $html .= $this->prepareItem($category, $node);
        }
        return $html;
    }

    public function prepareItem($category, $node, $level = 1)
    {
        $maxDepth = (int)$this->getMaxDepth();
        if ($maxDepth && ($level > $maxDepth)) return;
        $title = $category->getTitle();
        if ($this->showPostCount()) $title .= ' (' . $category->getPostCount() . ')';
        $item = $this->nodeFactory->create(
            [
                'data'    => [
                    'name' => $title,
                    'id'   => 'blog-note' . $category->getId(),
                    'url'  => $category->getUrl()
                ],
                'idField' => 'id',
                'tree'    => $this->_menu->getTree()
            ]
        );
        $children = $category->getChildren();
        if ($children) {
            foreach ($children as $_category) {
                $this->prepareItem($_category, $item, ++$level);
            }
        }
        $node->addChild($item);
    }

    /**
     * @return boolean
     */
    public function showPostCount()
    {
        return $this->dataHelper->getConfig('top_navigation/show_post_count');
    }

    /**
     * @return int
     */
    public function getMaxDepth()
    {
        return $this->dataHelper->getConfig('top_navigation/max_depth');
    }

    public function beforeGetHtml(
        \Magento\Theme\Block\Html\Topmenu $subject,
        $outermostClass = '',
        $childrenWrapClass = '',
        $limit = 0
    ) {
        if ($this->dataHelper->getConfig('top_navigation/enabled')) {
            $this->_menu = $subject->getMenu();
            $hasActive = false;
            $title = $this->dataHelper->getConfig('top_navigation/title');
            $blog  = $this->nodeFactory->create(
                [
                    'data'    => [
                        'name' => $title,
                        'id'   => 'blog-note',
                        'url'  => $this->dataHelper->getBLogUrl(),
                    ],
                    'idField' => 'id',
                    'tree'    => $subject->getMenu()->getTree()
                ]
            );
            if ($this->dataHelper->getConfig('top_navigation/include_categories')) $this->prepareMenu($blog);
            $subject->getMenu()->addChild($blog);
        }
    }
}