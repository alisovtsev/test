<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Sidebar;

class Tags extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory
     */
    protected $postCollectionFactory;

    /**
     * @var array
     */
    protected $_tags;

    /**
     * @var array
     */
    protected $_postCatgoryList;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Tag\Collection
     */
    protected $_collection;

    /**
     * @param \Magento\Framework\View\Element\Template\Context         $context               
     * @param \Magento\Framework\App\Http\Context                      $httpContext           
     * @param \Magento\Framework\App\ResourceConnection                $resource              
     * @param \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory  $collectionFactory     
     * @param \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory 
     * @param \Magezon\Blog\Helper\Data                                $dataHelper            
     * @param array                                                    $data                  
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory,
        \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
        \Magezon\Blog\Helper\Data $dataHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->httpContext           = $httpContext;
        $this->resource              = $resource;
        $this->collectionFactory     = $collectionFactory;
        $this->postCollectionFactory = $postCollectionFactory;
        $this->dataHelper            = $dataHelper;
    }

    protected function _construct()
    {
        parent::_construct();
        $this->addData([
            'cache_lifetime' => 86400,
            'cache_tags'     => [\Magezon\Blog\Model\Post::CACHE_TAG]
        ]);
    }

    /**
     * Get cache key informative items
     *
     * @return array
     */
    public function getCacheKeyInfo()
    {
        $cache = [
            'MGZ_BLOG_SIDEBAR_TAGS',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_GROUP)
        ];
        return $cache;
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Tag\Collection
     */
    public function getCollection()
    {
        if ($this->_collection === NULL) {
            $numberOfTags = (int)$this->dataHelper->getConfig('sidebar/tags/number_of_tags');
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('is_active', \Magezon\Blog\Model\Tag::STATUS_ENABLED);
            $collection->setPageSize($numberOfTags);
            if ($numberOfTags) {
                $collection->getSelect()->orderRand();
            }
            $this->_collection = $collection;
        }
        return $this->_collection;
    }

    /**
     * @return array
     */
    public function getPostTagList()
    {
        if ($this->_postCatgoryList === NULL) {
            $ids        = $this->getCollection()->getAllIds();
            $connection = $this->resource->getConnection();
            $table      = $this->resource->getTableName('mgz_blog_tag_post');
            $select     = $connection->select()->from($table)->where('tag_id IN (?)', $ids);
            $result     = $connection->fetchAll($select);

            $postCollection = $this->postCollectionFactory->create();
            $postCollection->getSelect()->joinLeft(
                ['mbcp' => $table],
                'main_table.post_id = mbcp.post_id',
                []
            )->group('main_table.post_id');
            $postCollection->prepareCollection();

            foreach ($result as $k => $row) { 
                if (!$postCollection->getItemById($row['post_id'])) {
                    unset($result[$k]);
                }
            }
            $this->_postCatgoryList = array_values($result);
        }
        return $this->_postCatgoryList;
    }

    /**
     * @param  \Magezon\Blog\Model\Tag $tag
     * @return integer
     */
    public function getPostCount($tag)
    {
        $count = 0;
        $list = $this->getPostTagList();
        if ($list) {
            foreach ($list as $_row) {
                if ($_row['tag_id'] == $tag->getId()) $count++;
            }
        }
        return $count;
    }

    /**
     * @return array
     */
    public function getTags()
    {
        if ($this->_tags === NULL) {
            $tags = [];
            $collection = $this->getCollection();
            foreach ($collection as $_tag) {
                $_tag->setPostCount($this->getPostCount($_tag));
            }
            $this->_tags = $collection;
        }
        return $this->_tags;
    }
}