<?php
namespace Magezon\Blog\Model\Tag\Source;

use Magento\Framework\Data\OptionSourceInterface;

class TagList implements OptionSourceInterface
{
    /**
     * @var \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory
     */
    public function __construct(
        \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $collection = $this->collectionFactory->create();
        $options = [];
        foreach ($collection as $author) {
            $options[] = [
                'label' => $author->getTitle(),
                'value' => $author->getId()
            ];
        }
        return $options;
    }
}
