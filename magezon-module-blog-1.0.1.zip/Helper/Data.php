<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Helper;

use Magezon\Blog\Model\Comment;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @param \Magento\Framework\App\Helper\Context      $context      
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager 
     * @param \Magento\Framework\UrlInterface            $urlBuilder   
     * @param \Magento\Framework\Registry                $registry     
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Framework\Registry $registry
    ) {
        parent::__construct($context);
        $this->_storeManager = $storeManager;
        $this->urlBuilder    = $urlBuilder;
        $this->registry      = $registry;
    }
   
    /**
     * @param  string $key
     * @param  null|int $store
     * @return null|string
     */
    public function getConfig($key, $store = null)
    {
        $store     = $this->_storeManager->getStore($store);
        $websiteId = $store->getWebsiteId();
        $result    = $this->scopeConfig->getValue(
            'mgzblog/' . $key,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store);
        return $result;
    }

    /**
     * @return boolean
     */
    public function isEnabled()
    {
        return $this->getConfig('general/enabled');
    }

    public function getRoute()
    {
        return $this->getConfig('permalink/route');
    }

    public function getDateFormat()
    {
        return $this->getConfig('general/date_format');
    }

    public function getPostUseCategories()
    {
        return $this->getConfig('permalink/post_use_categories');
    }

    public function getBlogUrl()
    {
        return $this->urlBuilder->getUrl(null, ['_direct' => $this->getRoute()]);
    }

    public function getBlogTitle()
    {
        return $this->getConfig('latest_page/title');
    }

    public function getPostUrlSuffix()
    {
        return $this->getConfig('permalink/post_suffix');
    }

    public function getCategoryRoute()
    {
        return $this->getConfig('permalink/category_route');
    }

    public function getCategoryUrlSuffix()
    {
        return $this->getConfig('permalink/category_suffix');
    }

    public function getAuthorRoute()
    {
        return $this->getConfig('permalink/author_route');
    }

    public function getAuthorUrlSuffix()
    {
        return $this->getConfig('permalink/author_suffix');
    }

    public function getTagRoute()
    {
        return $this->getConfig('permalink/tag_route');
    }

    public function getTagUrlSuffix()
    {
        return $this->getConfig('permalink/tag_suffix');
    }

    public function getSearchRoute()
    {
        return $this->getConfig('permalink/search_route');
    }

    public function getArchiveRoute()
    {
        return $this->getConfig('permalink/archive_route');
    }

    public function getArchiveUrlSuffix()
    {
        return $this->getConfig('permalink/archive_suffix');
    }

    public function getDefaultCommentStatus()
    {
        return $this->getConfig('post_page/comments/need_approve') ? Comment::STATUS_PENDING : Comment::STATUS_APPROVED;
    }

    public function isRssAllowed()
    {
        return $this->getConfig('rss/enabled');
    }

    public function enableTagPage()
    {
        return $this->getConfig('tag_page/enabled');
    }

    public function enableAuthorPage()
    {
        return $this->getConfig('author_page/enabled');
    }

    public function getArchiveUrl($month, $year)
    {
        $route      = $this->getRoute();
        $identifier = $route . '/' . $this->getArchiveRoute() . '/' . $year . '/' . $month . $this->getArchiveUrlSuffix();
        return $this->urlBuilder->getUrl(null, ['_direct' => $identifier]);
    }

    public function getArchiveTitle($type, $year, $month = null)
    {
        switch ($type) {
            case 'year':
                $title = __('Yearly Archives: %1', $year);
                break;
            
            default:
                $startTime = $year . '-' . $month . '-01 00:00:00';
                $_month = __(date('F', strtotime($startTime)));
                $title = __('Monthly Archives: %1', $_month . ' ' . $year);
                break;
        }
        return $title;
    }

    public function getCommentType()
    {
        return $this->getConfig('post_page/comments/type');
    }

    public function getCurrentLang()
    {
        $store = $this->_storeManager->getStore();
        return $this->scopeConfig->getValue(
            'general/locale/code',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store
        );
    }

    /**
     * @return string
     */
    public function getLatestPostsRssLink()
    {
        return $this->urlBuilder->getUrl('blog/feed/index', [
            'type'     => 'latest_posts',
            'store_id' => $this->_storeManager->getStore()->getId()
        ]);
    }

    public function isEnabledLatestPostsRss()
    {
        return ($this->getConfig('rss/enabled') && $this->getConfig('rss/latest_posts'));
    }

    /**
     * @return string
     */
    public function getCategoryRssLink()
    {
        return $this->urlBuilder->getUrl('blog/feed/index', [
            'type' => 'blog_category',
            'id'   => $this->registry->registry('current_category')->getId()
        ]);
    }

    public function isEnabledCategoryRss()
    {
        return ($this->getConfig('rss/enabled') && $this->getConfig('rss/latest_posts'));
    }
}