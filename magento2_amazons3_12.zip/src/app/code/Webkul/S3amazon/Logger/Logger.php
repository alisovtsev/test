<?php
/**
 * Webkul S3amazon Shipping.
 * @category  Webkul
 * @package   Webkul_S3amazon
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\S3amazon\Logger;

class Logger extends \Monolog\Logger
{

}
