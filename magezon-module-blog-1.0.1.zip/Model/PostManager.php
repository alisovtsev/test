<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Model;

class PostManager
{
    /**
     * @var array
     */
    protected $_cache = [];

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface               $storeManager      
     * @param \Magento\Customer\Model\Session                          $customerSession   
     * @param \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $collectionFactory 
     */
	public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $collectionFactory
	) {
        $this->storeManager      = $storeManager;
        $this->customerSession   = $customerSession;
        $this->collectionFactory = $collectionFactory;
	}

    /**
     * @param  int $storeId 
     * @return \Magezon\Blog\Model\ResourceModel\Post\Collection 
     */
    public function getPostCollection($storeId = null)
    {
		$store = $this->storeManager->getStore($storeId);
		$groupId = $this->customerSession->getCustomerGroupId();
		$collection = $this->collectionFactory->create();
        $collection->addIsActiveFilter()
        ->addStoreFilter($store)
        ->addCustomerGroupFilter($groupId);
        return $collection;
    }

    /**
     * @param  string $year  
     * @return \Magezon\Blog\Model\ResourceModel\Post\Collection   
     */
    public function getPostCollectionByYear($year)
    {
        if (!isset($this->_cache[$year])) {
            $startTime = $year . '-01-01 00:00:00';
            $endTime = $year . '-12-31 23:59:59';
            $collection = $this->collectionFactory->create();
            $collection->prepareCollection();
            $collection->addFieldToFilter(
                'publish_date',
                [
                    'from' => $startTime,
                    'to'   => $endTime
                ]
            );
            $collection->setOrder('publish_date', 'DESC');
            $this->_cache[$year] = $collection;
        }
        return $this->_cache[$year];
    }

    /**
     * @param  string $year  
     * @param  string $month 
     * @return \Magezon\Blog\Model\ResourceModel\Post\Collection 
     */
    public function getPostCollectionByMonth($year, $month)
    {
        if (!isset($this->_cache[$year . $month])) {
            $startTime = $year . '-' . $month . '-01 00:00:00';
            $endTime   = $year . '-' . $month . '-31 23:59:59';
            $collection = $this->collectionFactory->create();
            $collection->prepareCollection();
            $collection->addFieldToFilter(
                'publish_date',
                [
                    'from' => $startTime,
                    'to'   => $endTime
                ]
            );
            $collection->setOrder('publish_date', 'DESC');
            $this->_cache[$year . $month] = $collection;
        }
        return $this->_cache[$year . $month];
    }
}