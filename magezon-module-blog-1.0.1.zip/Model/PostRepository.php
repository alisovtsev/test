<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Model;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;

class PostRepository implements \Magezon\Blog\Api\PostRepositoryInterface
{
    /**
     * @var Post[]
     */
    protected $instances = [];

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magezon\Blog\Model\PostFactory
     */
    protected $postFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory
     */
    protected $postCollectionFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post
     */
    protected $postResource;

    /**
     * @var \Magezon\Blog\Api\Data\PostSearchResultsInterfaceFactory
     */
    protected $postSearchResultsFactory;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface               $storeManager
     * @param \Magezon\Blog\Model\PostFactory                          $postFactory
     * @param \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory
     * @param \Magezon\Blog\Model\ResourceModel\Post                   $postResource
     * @param \Magezon\Blog\Api\Data\PostSearchResultsInterfaceFactory $postSearchResultsFactory
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magezon\Blog\Model\PostFactory $postFactory,
        \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
        \Magezon\Blog\Model\ResourceModel\Post $postResource,
        \Magezon\Blog\Api\Data\PostSearchResultsInterfaceFactory $postSearchResultsFactory
    ) {
        $this->storeManager             = $storeManager;
        $this->postFactory              = $postFactory;
        $this->postCollectionFactory    = $postCollectionFactory;
        $this->postResource             = $postResource;
        $this->postSearchResultsFactory = $postSearchResultsFactory;
    }

    /**
     * Save post.
     *
     * @param \Magezon\Blog\Api\Data\PostInterface $post
     * @return \Magezon\Blog\Api\Data\PostInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Magezon\Blog\Api\Data\PostInterface $post)
    {
        $storeId = $post->getStoreId();
        if (!$storeId) {
            $storeId = (int) $this->storeManager->getStore()->getId();
        }

        if ($post->getId()) {
            $newData    = $post->getData();
            $post = $this->get($post->getId(), $storeId);
            foreach ($newData as $k => $v) {
                $post->setData($k, $v);
            }
        }

        try {
            $this->postResource->save($post);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(
                __(
                    'Could not save post: %1',
                    $e->getMessage()
                ),
                $e
            );
        }
        unset($this->instances[$post->getId()]);
        return $this->get($post->getId(), $storeId);
    }

    /**
     * Retrieve post.
     *
     * @param int $postId
     * @param int $storeId
     * @return \Magezon\Blog\Api\Data\PostInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($postId, $storeId = null)
    {
        $cacheKey = null !== $storeId ? $storeId : 'all';
        if (!isset($this->instances[$postId][$cacheKey])) {
            /** @var Post $post */
            $post = $this->postFactory->create();
            if (null !== $storeId) {
                $post->setStoreId($storeId);
            }
            $post->load($postId);

            if (!$post->getId()) {
                throw NoSuchEntityException::singleField('id', $postId);
            }
            $this->instances[$postId][$cacheKey] = $post;
        }
        return $this->instances[$postId][$cacheKey];
    }

    /**
     * Delete post.
     *
     * @param \Magezon\Blog\Api\Data\PostInterface $post
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Magezon\Blog\Api\Data\PostInterface $post)
    {
        try {
            $postId = $post->getId();
            $this->postResource->delete($post);
        } catch (\Exception $e) {
            throw new StateException(
                __(
                    'Cannot delete post with id %1',
                    $post->getId()
                ),
                $e
            );
        }
        unset($this->instances[$postId]);
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($postId)
    {
        $post = $this->get($postId);
        return  $this->delete($post);
    }

    /**
     * Load post data collection by given search criteria
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Magezon\Blog\Api\Data\PostSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->postSearchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Magezon\Blog\Model\ResourceModel\Post\Collection $collection */
        $collection = $this->postCollectionFactory->create();

        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }

        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
        $posts = [];

        foreach ($collection as $post) {
            $posts[] = $this->get($post->getId());
        }
        $searchResults->setItems($posts);
        return $searchResults;
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param \Magento\Framework\Api\Search\FilterGroup $filterGroup
     * @param \Magezon\Blog\Model\ResourceModel\Subission\Collection $collection
     * @return void
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        \Magento\Framework\Api\Search\FilterGroup $filterGroup,
        \Magezon\Blog\Model\ResourceModel\Post\Collection $collection
    ) {
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $collection->addFieldToFilter($filter->getField(), $filter->getValue());
        }
    }
}
