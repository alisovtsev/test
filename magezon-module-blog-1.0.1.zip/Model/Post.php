<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Model;

use Magezon\Blog\Api\Data\PostInterface;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;

class Post extends AbstractModel implements PostInterface, IdentityInterface
{
    /**#@+
     * Post's Statuses
     */
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;
    /**#@-*/

    const TYPE_IMAGE = 'image';
    const TYPE_VIDEO = 'video';

    const LAYOUT_FIXED_THUMBNAIL = 'fixed_thumb';
    const LAYOUT_FULL_THUMBNAIL  = 'full_thumb';
    const LAYOUT_GRID            = 'grid';
    const LAYOUT_MASONRY         = 'masonry';

    /**
     * CMS page cache tag
     */
    const CACHE_TAG = 'blog_p';

    /**
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'blog_post';

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Product\Collection
     */
    protected $productCollection;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Tag\Collection
     */
    protected $tagCollection;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Category\Collection
     */
    protected $categoryList;

    /**
     * @var \Magezon\Blog\Model\Author
     */
    protected $_author;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Post\Collection
     */
    protected $_relatedPostCollection;

    /**
     * @var \Magento\Framework\Filter\FilterManager
     */
    protected $filter;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magezon\Blog\Model\AuthorFactory
     */
    protected $_authorFactory;

    /**
     * @var \Magezon\Core\Helper\Data
     */
    protected $coreHelper;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magezon\Blog\Helper\Image
     */
    protected $imageHelper;

    /**
     * @param \Magento\Framework\Model\Context                             $context            
     * @param \Magento\Framework\Registry                                  $registry           
     * @param \Magento\Framework\Filter\FilterManager                      $filter             
     * @param \Magento\Framework\UrlInterface                              $urlBuilder         
     * @param \Magento\Store\Model\StoreManagerInterface                   $storeManager       
     * @param \Magezon\Blog\Model\AuthorFactory                            $authorFactory      
     * @param \Magezon\Core\Helper\Data                                    $coreHelper         
     * @param \Magezon\Blog\Helper\Data                                    $dataHelper         
     * @param \Magezon\Blog\Helper\Image                                   $imageHelper        
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource           
     * @param \Magento\Framework\Data\Collection\AbstractDb|null           $resourceCollection 
     * @param array                                                        $data               
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Filter\FilterManager $filter,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filter\FilterManager $filterManager,
        \Magezon\Blog\Model\AuthorFactory $authorFactory,
        \Magezon\Core\Helper\Data $coreHelper,
        \Magezon\Blog\Helper\Data $dataHelper,
        \Magezon\Blog\Helper\Image $imageHelper,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection);
        $this->filter         = $filter;
        $this->urlBuilder     = $urlBuilder;
        $this->storeManager   = $storeManager;
        $this->filterManager  = $filterManager;
        $this->_authorFactory = $authorFactory;
        $this->coreHelper     = $coreHelper;
        $this->dataHelper     = $dataHelper;
        $this->imageHelper    = $imageHelper;
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Magezon\Blog\Model\ResourceModel\Post::class);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId(), self::CACHE_TAG . '_' . $this->getIdentifier()];
    }

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId()
    {
        return parent::getData(self::POST_ID);
    }

    /**
     * Set ID
     *
     * @param int $id
     * @return PostInterface
     */
    public function setId($id)
    {
        return $this->setData(self::POST_ID, $id);
    }

    /**
     * Get identifier
     *
     * @return string
     */
    public function getIdentifier()
    {
        return parent::getData(self::IDENTIFIER);
    }

    /**
     * Set identifier
     *
     * @param string $identifier
     * @return PostInterface
     */
    public function setIdentifier($identifier)
    {
        return $this->setData(self::IDENTIFIER, $identifier);
    }

    /**
     * Get title
     *
     * @return string|null
     */
    public function getTitle()
    {
        return parent::getData(self::TITLE);
    }

    /**
     * Set title
     *
     * @param string $title
     * @return PostInterface
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * Get publish date
     *
     * @return string|null
     */
    public function getPublishDate()
    {
        if ($this->validateDate(parent::getData(self::PUBLISH_DATE))) return parent::getData(self::PUBLISH_DATE);
    }

    /**
     * Set publish date
     *
     * @param string $publishDate
     * @return PostInterface
     */
    public function setPublishDate($publishDate)
    {
        return $this->setData(self::PUBLISH_DATE, $publishDate);
    }

    /**
     * Get image
     *
     * @return string|null
     */
    public function getImage()
    {
        return parent::getData(self::IMAGE);
    }

    /**
     * Set image
     *
     * @param string $image
     * @return PostInterface
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     * Get content
     *
     * @return string|null
     */
    public function getContent()
    {
        return parent::getData(self::CONTENT);
    }

    /**
     * Set content
     *
     * @param string $content
     * @return PostInterface
     */
    public function setContent($content)
    {
        return $this->setData(self::CONTENT, $content);
    }

    /**
     * Get content
     *
     * @return string|null
     */
    public function getExcerpt()
    {
        return parent::getData(self::EXCERPT);
    }

    /**
     * Set excerpt
     *
     * @param string $excerpt
     * @return PostInterface
     */
    public function setExcerpt($excerpt)
    {
        return $this->setData(self::EXCERPT, $excerpt);
    }

    /**
     * Is active
     *
     * @return bool|null
     */
    public function isActive()
    {
        return parent::getData(self::IS_ACTIVE);
    }

    /**
     * Set is active
     *
     * @param int|bool $isActive
     * @return PostInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get author id
     *
     * @return int|null
     */
    public function getAuthorId()
    {
        return parent::getData(self::AUTHOR_ID);
    }

    /**
     * Set author id
     *
     * @param int $authorId
     * @return PostInterface
     */
    public function setAuthorId($authorId)
    {
        return $this->setData(self::AUTHOR_ID, $authorId);
    }

    /**
     * Get type
     *
     * @return string|null
     */
    public function getType()
    {
        return parent::getData(self::TYPE);
    }

    /**
     * Set type
     *
     * @param string $type
     * @return PostInterface
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * Get og title
     *
     * @return string|null
     */
    public function getOgTitle()
    {
        return parent::getData(self::OG_TITLE);
    }

    /**
     * Set og title
     *
     * @param string $ogTitle
     * @return PostInterface
     */
    public function setOgTitle($ogTitle)
    {
        return $this->setData(self::OG_TITLE, $ogTitle);
    }

    /**
     * Get og description
     *
     * @return string|null
     */
    public function getOgDescription()
    {
        return parent::getData(self::OG_DESCRIPTION);
    }

    /**
     * Set og description
     *
     * @param string $ogDescription
     * @return PostInterface
     */
    public function setOgDescription($ogDescription)
    {
        return $this->setData(self::OG_DESCRIPTION, $ogDescription);
    }

    /**
     * Get og img
     *
     * @return string|null
     */
    public function getOgImg()
    {
        return parent::getData(self::OG_IMG);
    }

    /**
     * Set og img
     *
     * @param string $ogImg
     * @return PostInterface
     */
    public function setOgImg($ogImg)
    {
        return $this->setData(self::OG_IMG, $ogImg);
    }

    /**
     * Get og type
     *
     * @return string|null
     */
    public function getOgType()
    {
        return parent::getData(self::OG_TYPE);
    }

    /**
     * Set og type
     *
     * @param string $ogType
     * @return PostInterface
     */
    public function setOgType($ogType)
    {
        return $this->setData(self::OG_TYPE, $ogType);
    }

    /**
     * Get meta title
     *
     * @return string|null
     */
    public function getMetaTitle()
    {
        return parent::getData(self::META_TITLE);
    }

    /**
     * Set meta title
     *
     * @param string $metaTitle
     * @return PostInterface
     */
    public function setMetaTitle($metaTitle)
    {
        return $this->setData(self::META_TITLE, $metaTitle);
    }

    /**
     * Get meta keywords
     *
     * @return string|null
     */
    public function getMetaKeywords()
    {
        return parent::getData(self::META_KEYWORDS);
    }

    /**
     * Set meta keywords
     *
     * @param string $metaKeywords
     * @return PostInterface
     */
    public function setMetaKeywords($metaKeywords)
    {
        return $this->setData(self::META_KEYWORDS, $metaKeywords);
    }

    /**
     * Get meta description
     *
     * @return string|null
     */
    public function getMetaDescription()
    {
        return parent::getData(self::META_DESCRIPTION);
    }

    /**
     * Set meta description
     *
     * @param string $metaDescription
     * @return PostInterface
     */
    public function setMetaDescription($metaDescription)
    {
        return $this->setData(self::META_DESCRIPTION, $metaDescription);
    }

    /**
     * Get video link
     *
     * @return string|null
     */
    public function getVideoLink()
    {
        return parent::getData(self::VIDEO_LINK);
    }

    /**
     * Set video link
     *
     * @param string $videoLink
     * @return PostInterface
     */
    public function setVideoLink($videoLink)
    {
        return $this->setData(self::VIDEO_LINK, $videoLink);
    }

    /**
     * Get creation time
     *
     * @return string|null
     */
    public function getCreationTime()
    {
        return parent::getData(self::CREATION_TIME);
    }

    /**
     * Set creation time
     *
     * @param string $creationTime
     * @return PostInterface
     */
    public function setCreationTime($creationTime)
    {
        return $this->setData(self::CREATION_TIME, $creationTime);
    }

    /**
     * Get update time
     *
     * @return string|null
     */
    public function getUpdateTime()
    {
        return parent::getData(self::UPDATE_TIME);
    }

    /**
     * Set update time
     *
     * @param string $updateTime
     * @return PostInterface
     */
    public function setUpdateTime($updateTime)
    {
        return $this->setData(self::UPDATE_TIME, $updateTime);
    }

    /**
     * Get total views
     *
     * @return int|null
     */
    public function getTotalViews()
    {
        return parent::getData(self::TOTAL_VIEWS);
    }

    /**
     * Set total views
     *
     * @param int $totalViews
     * @return PostInterface
     */
    public function setTotalViews($totalViews)
    {
        return $this->setData(self::TOTAL_VIEWS, $totalViews);
    }

    /**
     * Is featured
     *
     * @return bool|null
     */
    public function isFeatured()
    {
        return parent::getData(self::FEATURED);
    }

    /**
     * Set is featured
     *
     * @param int|bool $featured
     * @return PostInterface
     */
    public function setFeatured($featured)
    {
        return $this->setData(self::FEATURED, $featured);
    }

    /**
     * Is pinned
     *
     * @return bool|null
     */
    public function isPinned()
    {
        return parent::getData(self::PINNED);
    }

    /**
     * Set is pinned
     *
     * @param int|bool $pinned
     * @return PostInterface
     */
    public function setPinned($pinned)
    {
        return $this->setData(self::PINNED, $pinned);
    }

    /**
     * Get allow comment
     *
     * @return int|null
     */
    public function getAllowComment()
    {
        if (!$this->dataHelper->getConfig('post_page/comments/type')) return;
        return parent::getData(self::ALLOW_COMMENT);
    }

    /**
     * Set allow comment
     *
     * @param int $allowComment
     * @return PostInterface
     */
    public function setAllowComment($allowComment)
    {
        return $this->setData(self::ALLOW_COMMENT, $allowComment);
    }

    /**
     * Get page layout
     *
     * @return string|null
     */
    public function getPageLayout()
    {
        return parent::getData(self::PAGE_LAYOUT) ? parent::getData(self::PAGE_LAYOUT) : '2columns-right';
    }

    /**
     * Set page layout
     *
     * @param string $pageLayout
     * @return PostInterface
     */
    public function setPageLayout($pageLayout)
    {
        return $this->setData(self::PAGE_LAYOUT, $pageLayout);
    }

    /**
     * Get canonical url
     *
     * @return string|null
     */
    public function getCanonicalUrl()
    {
        return parent::getData(self::CANONICAL_URL);
    }

    /**
     * Set canonical url
     *
     * @param string $canonicalUrl
     * @return PostInterface
     */
    public function setCanonicalUrl($canonicalUrl)
    {
        return $this->setData(self::CANONICAL_URL, $canonicalUrl);
    }

    /**
     * Retrieve post products
     *
     * @return \Magento\Catalog\Model\ResourceModel\Product\Collection
     */
    public function getProductCollection()
    {
        if ($this->productCollection === null) {
            $this->productCollection = $this->_getResource()->getProductCollection($this);
        }
        return $this->productCollection;
    }

    /**
     * Retrieve post tags
     *
     * @return \Magezon\Blog\Model\ResourceModel\Tag\Collection
     */
    public function getTagCollection()
    {
        if ($this->tagCollection === null) {
            $this->tagCollection = $this->_getResource()->getTagCollection($this);
        }
        return $this->tagCollection;
    }

    /**
     * Retrieve post categories
     *
     * @return array
     */
    public function getCategoryList()
    {
        if ($this->categoryList === null) {
            $this->categoryList = $this->_getResource()->getCategoryList($this);
        }
        return $this->categoryList;
    }

    /**
     * @param array $categoryList
     */
    public function setCategoryList(array $categoryList)
    {
        $this->categoryList = $categoryList;
        return $this;
    }

    /**
     * @return \Magezon\Blog\Model\Author
     */
    public function getAuthor()
    {
        if ($this->_author === NULL && $this->getAuthorId()) {
            $author = $this->_authorFactory->create();
            $author->load($this->getAuthorId());
            if ($author->isActive()) {
                $this->_author = $author;
            } else {
                $this->_author = false;
            }
        }
        return $this->_author;
    }

    /**
     * @param \Magezon\Blog\Model\Author $author
     */
    public function setAuthor(\Magezon\Blog\Model\Author $author)
    {
        $this->_author = $author;
        return $this;
    }

    /**
     * Retrieve assigned category Ids
     *
     * @return array
     */
    public function getCategoryIds()
    {
        if (!$this->hasData('category_ids')) {
            $ids = $this->_getResource()->getCategoryIds($this->getId());
            $this->setData('category_ids', $ids);
        }
        return (array) $this->_getData('category_ids');
    }

    /**
     * Retrieve assigned tag Ids
     *
     * @return array
     */
    public function getTagIds()
    {
        if (!$this->hasData('tag_ids')) {
            $ids = $this->_getResource()->getTagIds($this->getId());
            $this->setData('tag_ids', $ids);
        }

        return (array) $this->_getData('tag_ids');
    }

    /**
     * Format URL key from name or defined key
     *
     * @param string $str
     * @return string
     */
    public function formatUrlKey($str)
    {
        return $this->filter->translitUrl($str);
    }
    
    /**
     * Retrieve array of posts id's for category
     *
     * The array returned has the following format:
     * array($productId => $position)
     *
     * @return array
     */
    public function getProductsPosition()
    {
        if (!$this->getId()) {
            return [];
        }

        $array = $this->getData('products_position');
        if ($array === null) {
            $array = $this->_getResource()->getProductsPosition($this);
            $this->setData('products_position', $array);
        }
        return $array;
    }

    private function validateDate($date, $format = 'Y-m-d H:i:s') {
        $d = \DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) === $date;
    }

    /**
     * @param  boolean $shortMonth
     * @return string
     */
    public function getCreatedAtFormatted($shortMonth = false)
    {
        $dateFormat = $this->dataHelper->getDateFormat();
        if ($shortMonth) $dateFormat = str_replace('F', 'M', $dateFormat);
        $date = $this->getCreationTime();
        if ($this->getPublishDate()) $date = $this->getPublishDate();
        return date($dateFormat, strtotime($date));
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        $dataHelper = $this->dataHelper;
        $route      = $dataHelper->getRoute();
        $identifier = $route . '/';
        if ($dataHelper->getPostUseCategories() && ($category = $this->getCategory())) {
            $identifier .= $category->getIdentifier() . '/';
        }
        $identifier .= $this->getIdentifier() . $dataHelper->getPostUrlSuffix();
        return $this->urlBuilder->getUrl(null, ['_direct' => $identifier]);
    }

    /**
     * @param  int $width  
     * @param  int $height 
     * @return string
     */
    public function getImageUrl($width = null, $height = null)
    {
        $image = $this->getData('image');
        if ($image) {
            if ($width && $height) {
                return $this->imageHelper->resize($image, $width, $height, 100, 'magezon/resized', ['keepAspectRatio' => false, 'keepFrame' => false]);
            }
            return $this->getMediaUrl() . $image;
        }
    }

    /**
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
        );
    }

    /**
     * @return array
     */
    public function getTypes()
    {
        return [
            self::TYPE_IMAGE => __('Image'),
            self::TYPE_VIDEO => __('Video')
        ];
    }

    /**
     * @return array
     */
    public function getLayouts()
    {
        return [
            self::LAYOUT_FIXED_THUMBNAIL => __('List - Fixed Thumbnail'),
            self::LAYOUT_FULL_THUMBNAIL  => __('List - Full Thumbnail'),
            self::LAYOUT_GRID            => __('Grid'),
            self::LAYOUT_MASONRY         => __('Masonry')
        ];
    }

    /**
     * @return string                         
     */
    public function getPostExcerpt()
    {
        if ($this->getExcerpt()) {
            $excerpt = $this->coreHelper->filter($this->getExcerpt());
        } else {
            $excerpt = $this->_stripTags($this->getContent());
            $excerpt = $this->coreHelper->substr(strip_tags($excerpt), 300);
        }
        return trim($excerpt) ? trim($excerpt) . ' ...' : '';
    }

    private function _stripTags($string, $allowableTags = '<p> <b>', $allowHtmlEntities = null)
    {
        $string = $this->coreHelper->filter($string);
        $string = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $string);
        $string = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $string);
        $string = $this->filterManager->stripTags(
            $string,
            ['allowableTags' => $allowableTags, 'escape' => $allowHtmlEntities]
        );
        return $string;
    }

    /**
     * @return string
     */
    public function getMetaCommentUrl()
    {
        $url = $this->getUrl();
        $commentType = $this->dataHelper->getCommentType();
        if ($commentType == Comment::TYPE_NATIVE) {
            $url .= ($this->getTotalComments() ? '#blog-post-comments' : '#respond');
        }
        if ($commentType == Comment::TYPE_DISQUS) {
            $url .= '#disqus_thread';
        }
        return $url;
    }

    /**
     * @return \Magezon\Blog\Model\Category|null
     */
    public function getCategory()
    {
        if (($categories = $this->getCategoryList()) && !empty($categories)) return $categories[0];
    }

    /**
     * @return string
     */
    public function getOgImageUrl()
    {
        $image = $this->getData('og_img');
        if ($image) return $this->getMediaUrl() . $image;
        return $this->getImageUrl();
    }
    
    /**
     * Retrieve array of posts id's for post
     *
     * The array returned has the following format:
     * array($productId => $position)
     *
     * @return array
     */
    public function getPostsPosition()
    {
        if (!$this->getId()) {
            return [];
        }

        $array = $this->getData('posts_position');
        if ($array === null) {
            $array = $this->_getResource()->getPostsPosition($this);
            $this->setData('posts_position', $array);
        }
        return $array;
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Post\Collection
     */
    public function getRelatedPostCollection()
    {
        if ($this->_relatedPostCollection === null) {
            $this->_relatedPostCollection = $this->_getResource()->getRelatedPostCollection($this);
        }
        return $this->_relatedPostCollection;
    }
}