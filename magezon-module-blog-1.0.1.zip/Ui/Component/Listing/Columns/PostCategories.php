<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

class PostCategories extends Column
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param ContextInterface                                             $context            
     * @param UiComponentFactory                                           $uiComponentFactory 
     * @param \Magento\Framework\App\ResourceConnection                    $resource           
     * @param \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory $collectionFactory  
     * @param array                                                        $components         
     * @param array                                                        $data               
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magezon\Blog\Model\ResourceModel\Category\CollectionFactory $collectionFactory,
        array $components = [],
        array $data = []
    ) {
        $this->resource          = $resource;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $connection = $this->resource->getConnection();
            $select = $connection->select()->from($this->resource->getTableName('mgz_blog_category_post'));
            $list = $connection->fetchAll($select);
            $catIds = [];
            foreach ($list as $_row) {
                $catIds[] = $_row['category_id'];
            }
            $categoryCollection = $this->collectionFactory->create();
            $categoryCollection->addFieldToFilter('category_id', ['in' => $catIds]);
            foreach ($dataSource['data']['items'] as & $item) {
                $html = '';
                foreach ($list as $_row) {
                    if ($item['post_id'] == $_row['post_id']) {
                        $category = $categoryCollection->getItemById($_row['category_id']);
                        if ($category) {
                            if ($html) $html .= ', ';
                            $html .= $category->getTitle();
                        }
                    }
                }
                $item[$this->getData('name')] = $html;
            }
        }
        return $dataSource;
    }
}
