<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Tag;

class View extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context    
     * @param \Magento\Framework\Registry                      $registry   
     * @param \Magezon\Blog\Helper\Data                        $dataHelper 
     * @param array                                            $data       
     */
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magezon\Blog\Helper\Data $dataHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_coreRegistry = $registry;
        $this->dataHelper    = $dataHelper;
    }

    /**
     * Prepare global layout
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $this->_addBreadcrumbs();
        $tag = $this->getCurrentTag();
        $this->pageConfig->getTitle()->set($tag->getMetaTitle() ? $tag->getMetaTitle() : $tag->getTitle());
        $this->pageConfig->setKeywords($tag->getMetaKeywords());
        $this->pageConfig->setDescription($tag->getMetaDescription());
        $pageMainTitle = $this->getLayout()->getBlock('page.main.title');
        if ($pageMainTitle) $pageMainTitle->setPageTitle(__('Tag Archives: %1', $tag->getTitle()));
        $this->pageConfig->addRemotePageAsset(
            $tag->getCanonicalUrl() ? $tag->getCanonicalUrl() : $tag->getUrl(),
            'canonical',
            ['attributes' => ['rel' => 'canonical']]
        );
        return parent::_prepareLayout();
    }

    /**
     * Prepare breadcrumbs
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return void
     */
    protected function _addBreadcrumbs()
    {
		$breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs');
		if ($breadcrumbsBlock) {
            $breadcrumbsBlock->addCrumb(
                'home',
                [
                    'label' => __('Home'),
                    'title' => __('Go to Home Page'),
                    'link' => $this->_storeManager->getStore()->getBaseUrl()
                ]
            );
			$title = $this->dataHelper->getBlogTitle();
            $breadcrumbsBlock->addCrumb(
                'blog',
                [
                    'label' => $title,
                    'title' => $title,
                    'link' => $this->dataHelper->getBlogUrl()
                ]
            );
            $tag = $this->getCurrentTag();
            if ($title) $breadcrumbsBlock->addCrumb('tag', ['label' => __('Tag Archives: %1', $tag->getTitle()), 'title' => __('Tag Archives: %1', $tag->getTitle())]);
        }
    }

    /**
     * Retrieve current tag model object
     *
     * @return \Magezon\Blog\Model\Tag
     */
    public function getCurrentTag()
    {
        return $this->_coreRegistry->registry('current_tag');
    }

    /**
     * @return string
     */
	public function getPostListHtml()
	{
		$tag = $this->getCurrentTag();
		$collection = $tag->getPostCollection();
		$block = $this->getLayout()->createBlock(\Magezon\Blog\Block\ListPost::class);
		$block->setCollection($collection);
        $block->setShowPager(true);
        $block->setShowAuthor($this->dataHelper->getConfig('post_listing/post_author'));
        $block->setShowDate($this->dataHelper->getConfig('post_listing/post_date'));
        $block->setShowCategory($this->dataHelper->getConfig('post_listing/post_cats'));
        $block->setShowComment($this->dataHelper->getConfig('post_listing/post_comments'));
        $block->setShowView($this->dataHelper->getConfig('post_listing/post_views'));
		$data['list_layout'] = $this->dataHelper->getConfig('tag_page/layout');
		$data['grid_col']    = $this->dataHelper->getConfig('tag_page/grid_col');
		$block->addData($data);
		return $block->toHtml();
	}
}