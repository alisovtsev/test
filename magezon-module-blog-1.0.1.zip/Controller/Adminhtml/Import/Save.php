<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Controller\Adminhtml\Import;

use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Magezon_Blog::import';

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var \Magezon\Blog\Model\Import\AheadworksFactory
     */
    protected $aheadworksFactory;

    /**
     * @var \Magezon\Blog\Model\Import\AmastyFactory
     */
    protected $amastyFactory;

    /**
     * @var \Magezon\Blog\Model\Import\MageFanFactory
     */
    protected $magefanFactory;

    /**
     * @var \Magezon\Blog\Model\Import\MagePlazaFactory
     */
    protected $mageplazaFactory;

    /**
     * @var \Magezon\Blog\Model\Import\WordpressFactory
     */
    protected $wordpressFactory;

    /**
     * @param \Magento\Backend\App\Action\Context                   $context           
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor     
     * @param \Magezon\Blog\Model\Import\AheadworksFactory          $aheadworksFactory 
     * @param \Magezon\Blog\Model\Import\AmastyFactory              $amastyFactory     
     * @param \Magezon\Blog\Model\Import\MageFanFactory             $magefanFactory    
     * @param \Magezon\Blog\Model\Import\MagePlazaFactory           $mageplazaFactory  
     * @param \Magezon\Blog\Model\Import\WordpressFactory           $wordpressFactory  
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magezon\Blog\Model\Import\AheadworksFactory $aheadworksFactory,
        \Magezon\Blog\Model\Import\AmastyFactory $amastyFactory,
        \Magezon\Blog\Model\Import\MageFanFactory $magefanFactory,
        \Magezon\Blog\Model\Import\MagePlazaFactory $mageplazaFactory,
        \Magezon\Blog\Model\Import\WordpressFactory $wordpressFactory
    ) {
        $this->dataPersistor     = $dataPersistor;
        $this->aheadworksFactory = $aheadworksFactory;
        $this->amastyFactory     = $amastyFactory;
        $this->magefanFactory    = $magefanFactory;
        $this->mageplazaFactory  = $mageplazaFactory;
        $this->wordpressFactory  = $wordpressFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            try {
                switch ($data['type']) {

                    case 'aheadworks':
                        $import = $this->aheadworksFactory->create();
                        break;

                    case 'amasty':
                        $import = $this->amastyFactory->create();
                        break;

                    case 'magefan':
                        $import = $this->magefanFactory->create();
                        break;

                    case 'mageplaza':
                        $import = $this->mageplazaFactory->create();
                        break;

                    case 'wordpress':
                        $import = $this->wordpressFactory->create();
                        break;
                }
                if (isset($import)) {
                    $import->addData($data);
                    $import->import();
                    $this->messageManager->addSuccess(__(
                        'Import successfully done. %1 posts, %2 categories, %3 tags and %4 comments where imported.',
                        count($import->getImportedPosts()),
                        count($import->getImportedCategories()),
                        count($import->getImportedTags()),
                        count($import->getImportedComments())
                    ));
                    $this->dataPersistor->clear('blog_import');
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addExceptionMessage($e->getPrevious() ?:$e);
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while process the request.'));
            }
        }
        $this->dataPersistor->set('blog_import', $data);
        return $resultRedirect->setPath('*/*/');
    }
}
