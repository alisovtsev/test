<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Post;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Request\DataPersistorInterface;

class Comments extends \Magezon\Blog\Block\Post\View
{
    /**
     * Default value for products count that will be shown
     */
    const DEFAULT_COMMENTS_COUNT = 10;

    const DEFAULT_COMMENTS_PER_PAGE = 0;

    const DEFAULT_SHOW_PAGER = true;

    const PAGE_VAR_NAME = 'bc';

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment\Collection
     */
    protected $_collection;

    /**
     * @var array
     */
    protected $_comments;

    /**
     * @var \Magento\Theme\Block\Html\Pager
     */
    protected $pager;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context            $context           
     * @param \Magento\Framework\Registry                                 $registry          
     * @param \Magezon\Blog\Helper\Data                                   $dataHelper        
     * @param \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $collectionFactory 
     * @param array                                                       $data              
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magezon\Blog\Helper\Data $dataHelper,
        \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $collectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $registry, $dataHelper, $data);
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Retrieve how many comments should be displayed
     *
     * @return int
     */
    public function getCommentsCount()
    {
        if ($this->hasData('posts_count')) {
            return $this->getData('posts_count');
        }

        if (null === $this->getData('posts_count')) {
            $this->setData('posts_count', self::DEFAULT_COMMENTS_COUNT);
        }

        return $this->getData('posts_count');
    }

    /**
     * Retrieve how many comments should be displayed
     *
     * @return int
     */
    public function getCommentsPerPage()
    {
        if (!$this->hasData('posts_per_page')) {
            $this->setData('posts_per_page', self::DEFAULT_COMMENTS_PER_PAGE);
        }
        return $this->getData('posts_per_page');
    }

    /**
     * Return flag whether pager need to be shown or not
     *
     * @return bool
     */
    public function showPager()
    {
        if (!$this->hasData('show_pager')) {
            $this->setData('show_pager', self::DEFAULT_SHOW_PAGER);
        }
        return (bool)$this->getData('show_pager');
    }

    /**
     * Retrieve how many comments should be displayed on page
     *
     * @return int
     */
    protected function getPageSize()
    {
        return $this->showPager() ? $this->getCommentsPerPage() : $this->getCommentsCount();
    }

    /**
     * Return flag whether pager need to be shown or not
     *
     * @return bool
     */
    public function getPageVarName()
    {
        if (!$this->hasData('page_var_name')) {
            $this->setData('page_var_name', self::PAGE_VAR_NAME);
        }
        return $this->getData('page_var_name');
    }

    /**
     * Render pagination HTML
     *
     * @return string
     */
    public function getPagerHtml()
    {
        $size = $this->getCollection()->getSize();
        if ($this->showPager() && $size > $this->getCommentsPerPage() && $this->getPostsPerPage()) {
            if (!$this->pager) {
                $this->pager = $this->getLayout()->createBlock(
                    \Magento\Theme\Block\Html\Pager::class
                );
                $this->pager->setUseContainer(true)
                    ->setShowAmounts(true)
                    ->setShowPerPage(false)
                    ->setPageVarName($this->getPageVarName())
                    ->setLimit($this->getCommentsPerPage())
                    ->setTotalLimit($this->getCommentsCount())
                    ->setCollection($this->getCollection());
            }
            if ($this->pager instanceof \Magento\Framework\View\Element\AbstractBlock) {
                return $this->pager->toHtml();
            }
        }
        return '';
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Comment\Collection
     */
    public function getCollection()
    {
        if ($this->_collection === NULL) {
            $post = $this->getCurrentPost();
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('post_id', $post->getId());
            $collection->addFieldToFilter('status', \Magezon\Blog\Model\Comment::STATUS_APPROVED);
            $collection->addFieldToFilter('parent_id', 0);
            $collection->addPostInformation();
            $collection->addCustomerInformation();
            $collection->setPageSize($this->getPageSize())->setCurPage($this->getRequest()->getParam($this->getPageVarName(), 1));
            $this->_collection = $collection;
        }
        return $this->_collection;
    }

    /**
     * @return array
     */
    public function getComments()
    {
        if ($this->_comments === NULL) {
            $comments = [];
            $ids = [];
            foreach ($this->getCollection() as $_comment) {
                if (!$_comment->getParentId()) {
                    $comments[] = $_comment;
                    $ids[] = $_comment->getId();
                }
            }
            $post = $this->getCurrentPost();
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('post_id', $post->getId());
            $collection->addFieldToFilter('post_id', ['nin' => $ids]);
            $collection->addFieldToFilter('status', \Magezon\Blog\Model\Comment::STATUS_APPROVED);
            $collection->addPostInformation();
            $collection->addCustomerInformation();
            $this->_items = $collection->getItems();
            foreach ($comments as &$_comment) {
                $children = $this->prepareList($_comment);
                if ($children) $_comment->setChildren($children);
            }
            $this->_comments = $comments;
        }
        return $this->_comments;
    }

    /**
     * @param  \Magezon\Blog\Model\Comment $comment
     * @return array
     */
    private function prepareList($comment)
    {
        $childrens = [];
        foreach ($this->_items as $k => $_comment) {
            if ($_comment->getParentId() == $comment->getId()) {
                $hasChildren = false;
                $children = $_comment;
                foreach ($this->_items as $_comment2) {
                    if ($_comment2->getParentId() == $_comment->getId()) {
                        $hasChildren = true;
                        break;
                    }
                }
                if ($hasChildren && ($_children = $this->prepareList($children))) {
                    $children->setChildren($_children);
                }
                $childrens[] = $children;
            }
        }
        return $childrens;
    }

    /**
     * @return string
     */
    public function getCommentsHtml()
    {
        $html = '';
        $comments = $this->_comments;
        foreach ($comments as $comment) {
            $html .= $this->getCommentHtml($comment);
        }
        return $html;
    }

    /**
     * @param  \Magezon\Blog\Model\Comment $comment
     * @return string
     */
    public function getCommentHtml($comment)
    {
        $html = '';
        $html .= '<li id="comment-' . $comment->getId() . '">';
            $html .= '<div class="blog-comment-wrapper">';
                $html .= '<div class="blog-comment-avatar">';
                    $html .= '<img src="' . $comment->getImageUrl() . '" height="65" width="65"/>';
                $html .= '</div>';
                $html .= '<div class="blog-comment-content-wrapper">';
                    $html .= '<div class="blog-comment-author-wrapper">';
                        $html .= '<div class="blog-comment-author"><span>' . $this->escapeHtml($comment->getAuthor()) . '</span></div>';
                        $html .= '<div class="blog-comment-meta"><a href="' . $comment->getUrl() . '">' . $comment->getCreatedAtFormatted() . '</a></div>';
                    $html .= '</div>';
                    $html .= '<div class="blog-comment-content">' . $this->escapeHtml(nl2br($comment->getContent())) . '</div>';
                    $html .= '<div class="blog-comment-content-reply">';
                        $html .= '<span class="blog-comment-reply-link" data-parent-id="' . $comment->getId() . '">' . __('Reply') . '</span>';
                    $html .= '</div>';
                $html .= '</div>';
            $html .= '</div>';
            if ($children = $comment->getChildren()) {
                $html .= '<ul class="blog-comment-children">';
                foreach ($children as $_comment) {
                    $html .= $this->getCommentHtml($_comment);
                }
                $html .= '</ul>';
            }
        $html .= '</li>';
        return $html;
    }
}