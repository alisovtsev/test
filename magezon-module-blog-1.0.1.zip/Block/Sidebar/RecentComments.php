<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Sidebar;

class RecentComments extends \Magento\Framework\View\Element\Template
{	
    /**
     * @var \Magento\Framework\App\Http\Context
     */
	protected $httpContext;

    /**
     * @var \Magento\Framework\Stdlib\StringUtils
     */
    protected $string;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment\Collection
     */
    protected $_collection;

    /**
     * @param \Magento\Framework\View\Element\Template\Context            $context           
     * @param \Magento\Framework\App\Http\Context                         $httpContext       
     * @param \Magento\Framework\Stdlib\StringUtils                       $string            
     * @param \Magezon\Blog\Helper\Data                                   $dataHelper        
     * @param \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $collectionFactory 
     * @param array                                                       $data              
     */
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Framework\Stdlib\StringUtils $string,
        \Magezon\Blog\Helper\Data $dataHelper,
        \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $collectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->httpContext       = $httpContext;
        $this->string            = $string;
        $this->dataHelper        = $dataHelper;
        $this->collectionFactory = $collectionFactory;
    }

    protected function _construct()
    {
        parent::_construct();
        $this->addData([
            'cache_lifetime' => 86400,
            'cache_tags'     => [\Magezon\Blog\Model\Comment::CACHE_TAG]
        ]);
    }

    /**
     * Get cache key informative items
     *
     * @return array
     */
    public function getCacheKeyInfo()
    {
        $cache = [
            'MGZ_BLOG_SIDEBAR_RECENTCOMMENTS',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_GROUP)
        ];
        return $cache;
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Comment\Collection
     */
    public function getCollection()
    {
        if ($this->_collection === NULL) {
            $numberOfComments = (int)$this->dataHelper->getConfig('sidebar/tabs/recent_comments/number_of_comments');
            $post = $this->getCurrentPost();
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('status', \Magezon\Blog\Model\Comment::STATUS_APPROVED);
            $collection->addPostInformation();
            $collection->addCustomerInformation();
            $collection->setOrder('comment_id', 'DESC');
            $collection->setPageSize($numberOfComments);
            $this->_collection = $collection;
        }
        return $this->_collection;
    }

    /**
     * @param  \Magezon\Blog\Model\Comment $comment 
     * @return string          
     */
    public function getCommentContent($comment)
    {
    	return $this->string->substr(strip_tags($comment->getContent()), 0, 100);
    }
}