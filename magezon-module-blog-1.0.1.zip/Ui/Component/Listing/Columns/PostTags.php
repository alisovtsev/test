<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

class PostTags extends Column
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resource;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param ContextInterface                                        $context            
     * @param UiComponentFactory                                      $uiComponentFactory 
     * @param \Magento\Framework\App\ResourceConnection               $resource           
     * @param \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory  
     * @param array                                                   $components         
     * @param array                                                   $data               
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magezon\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory,
        array $components = [],
        array $data = []
    ) {
        $this->resource          = $resource;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $connection = $this->resource->getConnection();
            $select = $connection->select()->from($this->resource->getTableName('mgz_blog_tag_post'));
            $list = $connection->fetchAll($select);
            $catIds = [];
            foreach ($list as $_row) {
                $catIds[] = $_row['tag_id'];
            }
            $tagCollection = $this->collectionFactory->create();
            $tagCollection->addFieldToFilter('tag_id', ['in' => $catIds]);
            foreach ($dataSource['data']['items'] as & $item) {
                $html = '';
                foreach ($list as $_row) {
                    if ($item['post_id'] == $_row['post_id']) {
                        $tag = $tagCollection->getItemById($_row['tag_id']);
                        if ($tag) {
                            if ($html) $html .= ', ';
                            $html .= $tag->getTitle();
                        }
                    }
                }
                $item[$this->getData('name')] = $html;
            }
        }
        return $dataSource;
    }
}
