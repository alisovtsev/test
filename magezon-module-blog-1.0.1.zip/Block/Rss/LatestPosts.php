<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Rss;

use Magento\Framework\App\Rss\DataProviderInterface;

class LatestPosts extends \Magento\Framework\View\Element\AbstractBlock implements DataProviderInterface
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magezon\Blog\Model\PostManager
     */
    protected $postManager;

    /**
     * @var \Magezon\Blog\Helper\Data
     */
    protected $dataHelper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context     
     * @param \Magento\Framework\UrlInterface                  $urlBuilder  
     * @param \Magezon\Blog\Model\PostManager                  $postManager 
     * @param \Magezon\Blog\Helper\Data                        $dataHelper  
     * @param array                                            $data        
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magezon\Blog\Model\PostManager $postManager,
        \Magezon\Blog\Helper\Data $dataHelper,
        array $data = []
    ) {
        $this->storeManager  = $context->getStoreManager();
        $this->urlBuilder    = $urlBuilder;
        $this->postManager   = $postManager;
        $this->dataHelper    = $dataHelper;
        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->setCacheKey('rss_blog_latest_posts_store_' . $this->getStoreId());
        parent::_construct();
    }

    /**
     * boolean
     */
    public function isAllowed()
    {
        return ($this->dataHelper->isRssAllowed() && $this->dataHelper->getConfig('rss/latest_posts'));
    }

    /**
     * array
     */
    public function getRssData()
    {
        $storeModel = $this->storeManager->getStore($this->getStoreId());
        $link       = $this->urlBuilder->getUrl('blog/feed/index', [
            'type'     => 'latest_posts',
            'store_id' => $this->getStoreId()
        ]);
        $title      = __('Latest Posts from %1', $storeModel->getFrontendName());
        $lang       = $this->_scopeConfig->getValue(
            'general/locale/code',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeModel
        );
        $data = [
            'title'       => (string)$title,
            'description' => (string)$title,
            'link'        => $this->getRssLink(),
            'charset'     => 'UTF-8',
            'language'    => $lang
        ];
        $collection = $this->postManager->getPostCollection($this->getStoreId());
        $collection->setOrder('publish_date', 'DESC');
        foreach ($collection as $post) {
            $data['entries'][] = [
                'title'       => $post->getTitle(),
                'link'        => $post->getUrl(),
                'image'       => $post->getImageUrl(),
                'description' => $post->getPostExcerpt(),
                'lastUpdate'  => strtotime($post->getPublishDate())
            ];
        }
        return $data;
    }

    /**
     * @return int
     */
    protected function getStoreId()
    {
        $storeId = (int)$this->getRequest()->getParam('store_id');
        if ($storeId == null) $storeId = $this->storeManager->getStore()->getId();
        return $storeId;
    }

    /**
     * integer
     */
    public function getCacheLifetime()
    {
        return 600;
    }

    /**
     * @return array
     */
    public function getFeeds()
    {
        $data = [];
        if ($this->isAllowed()) {
            $url = $this->getRssLink();
            $data = ['label' => __('Latest Posts'), 'link' => $url];
        }
        return $data;
    }

    /**
     * boolean
     */
    public function isAuthRequired()
    {
        return false;
    }

    public function getRssLink()
    {
        return $this->dataHelper->getBlogUrl();
    }
}
