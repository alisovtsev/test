<?php
namespace Magezon\Blog\Model\User\Source;

use Magento\Framework\Data\OptionSourceInterface;

class UserList implements OptionSourceInterface
{
    /**
     * @var \Magezon\Blog\Model\ResourceModel\Author\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param \Magezon\Blog\Model\ResourceModel\Author\CollectionFactory $collectionFactory
     */
    public function __construct(
        \Magento\User\Model\ResourceModel\User\CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $collection = $this->collectionFactory->create();
        $collection->setOrder('firstname', 'ASC');
        $options = [];
        foreach ($collection as $author) {
            $options[] = [
                'label' => $author->getFirstname() . ' ' . $author->getLastname(),
                'value' => $author->getId()
            ];
        }
        return $options;
    }
}
