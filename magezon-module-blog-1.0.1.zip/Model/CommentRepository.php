<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Model;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;

class CommentRepository implements \Magezon\Blog\Api\CommentRepositoryInterface
{
    /**
     * @var Comment[]
     */
    protected $instances = [];

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magezon\Blog\Model\CommentFactory
     */
    protected $commentFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory
     */
    protected $commentCollectionFactory;

    /**
     * @var \Magezon\Blog\Model\ResourceModel\Comment
     */
    protected $commentResource;

    /**
     * @var \Magezon\Blog\Api\Data\CommentSearchResultsInterfaceFactory
     */
    protected $commentSearchResultsFactory;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface               $storeManager
     * @param \Magezon\Blog\Model\CommentFactory                          $commentFactory
     * @param \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $commentCollectionFactory
     * @param \Magezon\Blog\Model\ResourceModel\Comment                   $commentResource
     * @param \Magezon\Blog\Api\Data\CommentSearchResultsInterfaceFactory $commentSearchResultsFactory
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magezon\Blog\Model\CommentFactory $commentFactory,
        \Magezon\Blog\Model\ResourceModel\Comment\CollectionFactory $commentCollectionFactory,
        \Magezon\Blog\Model\ResourceModel\Comment $commentResource,
        \Magezon\Blog\Api\Data\CommentSearchResultsInterfaceFactory $commentSearchResultsFactory
    ) {
        $this->storeManager             = $storeManager;
        $this->commentFactory              = $commentFactory;
        $this->commentCollectionFactory    = $commentCollectionFactory;
        $this->commentResource             = $commentResource;
        $this->commentSearchResultsFactory = $commentSearchResultsFactory;
    }

    /**
     * Save comment.
     *
     * @param \Magezon\Blog\Api\Data\CommentInterface $comment
     * @return \Magezon\Blog\Api\Data\CommentInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Magezon\Blog\Api\Data\CommentInterface $comment)
    {
        $storeId = $comment->getStoreId();
        if (!$storeId) {
            $storeId = (int) $this->storeManager->getStore()->getId();
        }

        if ($comment->getId()) {
            $newData    = $comment->getData();
            $comment = $this->get($comment->getId(), $storeId);
            foreach ($newData as $k => $v) {
                $comment->setData($k, $v);
            }
        }

        try {
            $this->commentResource->save($comment);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(
                __(
                    'Could not save comment: %1',
                    $e->getMessage()
                ),
                $e
            );
        }
        unset($this->instances[$comment->getId()]);
        return $this->get($comment->getId(), $storeId);
    }

    /**
     * Retrieve comment.
     *
     * @param int $commentId
     * @param int $storeId
     * @return \Magezon\Blog\Api\Data\CommentInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($commentId, $storeId = null)
    {
        $cacheKey = null !== $storeId ? $storeId : 'all';
        if (!isset($this->instances[$commentId][$cacheKey])) {
            /** @var Comment $comment */
            $comment = $this->commentFactory->create();
            if (null !== $storeId) {
                $comment->setStoreId($storeId);
            }
            $comment->load($commentId);

            if (!$comment->getId()) {
                throw NoSuchEntityException::singleField('id', $commentId);
            }
            $this->instances[$commentId][$cacheKey] = $comment;
        }
        return $this->instances[$commentId][$cacheKey];
    }

    /**
     * Delete comment.
     *
     * @param \Magezon\Blog\Api\Data\CommentInterface $comment
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Magezon\Blog\Api\Data\CommentInterface $comment)
    {
        try {
            $commentId = $comment->getId();
            $this->commentResource->delete($comment);
        } catch (\Exception $e) {
            throw new StateException(
                __(
                    'Cannot delete comment with id %1',
                    $comment->getId()
                ),
                $e
            );
        }
        unset($this->instances[$commentId]);
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($commentId)
    {
        $comment = $this->get($commentId);
        return  $this->delete($comment);
    }

    /**
     * Load comment data collection by given search criteria
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Magezon\Blog\Api\Data\CommentSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->commentSearchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Magezon\Blog\Model\ResourceModel\Comment\Collection $collection */
        $collection = $this->commentCollectionFactory->create();

        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }

        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
        $comments = [];

        foreach ($collection as $comment) {
            $comments[] = $this->get($comment->getId());
        }
        $searchResults->setItems($comments);
        return $searchResults;
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param \Magento\Framework\Api\Search\FilterGroup $filterGroup
     * @param \Magezon\Blog\Model\ResourceModel\Subission\Collection $collection
     * @return void
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        \Magento\Framework\Api\Search\FilterGroup $filterGroup,
        \Magezon\Blog\Model\ResourceModel\Comment\Collection $collection
    ) {
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $collection->addFieldToFilter($filter->getField(), $filter->getValue());
        }
    }
}
