<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Block\Sidebar;

class PopularPosts extends \Magento\Framework\View\Element\Template
{
	/**
	 * @var \Magento\Framework\App\Http\Context
	 */
	protected $httpContext;

	/**
	 * @var \Magezon\Blog\Helper\Data
	 */
	protected $dataHelper;

	/**
	 * @var \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory
	 */
	protected $collectionFactory;

	/**
	 * @var \Magezon\Blog\Model\ResourceModel\Post\Collection
	 */
	protected $_collection;

	/**
	 * @param \Magento\Framework\View\Element\Template\Context         $context           
	 * @param \Magento\Framework\App\Http\Context                      $httpContext       
	 * @param \Magezon\Blog\Helper\Data                                $dataHelper        
	 * @param \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $collectionFactory 
	 * @param array                                                    $data              
	 */
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magezon\Blog\Helper\Data $dataHelper,
        \Magezon\Blog\Model\ResourceModel\Post\CollectionFactory $collectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
		$this->httpContext       = $httpContext;
		$this->dataHelper        = $dataHelper;
		$this->collectionFactory = $collectionFactory;
    }

    protected function _construct()
    {
        parent::_construct();
        $this->addData([
            'cache_lifetime' => 86400,
            'cache_tags'     => [\Magezon\Blog\Model\Post::CACHE_TAG]
        ]);
    }

    /**
     * Get cache key informative items
     *
     * @return array
     */
    public function getCacheKeyInfo()
    {
        $cache = [
            'MGZ_BLOG_SIDEBAR_POPULARPOSTS',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_GROUP)
        ];
        return $cache;
    }

    /**
     * @return \Magezon\Blog\Model\ResourceModel\Post\Collection
     */
    public function getCollection()
    {
    	if ($this->_collection === NULL) {
    		$numberOfPosts = (int)$this->dataHelper->getConfig('sidebar/tabs/popular_posts/number_of_posts');
			$collection = $this->collectionFactory->create();
			$collection->prepareCollection();
			$collection->addAuthorToCollection();
			$collection->addTotalComments();
			$collection->setOrder('total_views', 'DESC');
			$collection->setPageSize($numberOfPosts);
			$this->_collection = $collection;
		}
		return $this->_collection;
    }

    /**
     * @return string
     */
	public function getPostListHtml()
	{
		$collection = $this->getCollection();
		$block = $this->getLayout()->createBlock(\Magezon\Blog\Block\ListPost::class);
		$block->setCollection($collection);
		$block->setTemplate('Magezon_Blog::post/list2.phtml');
		$block->setShowAuthor(false);
		$block->setShowComment(false);
		$block->setShowCategory(false);
		return $block->toHtml();
	}
}