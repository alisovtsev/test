<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        /**
         * Create table 'mgz_blog_post'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_post')
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'identifier',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Title'
        )->addColumn(
            'title',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Title'
        )->addColumn(
            'type',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Type'
        )->addColumn(
            'publish_date',
            Table::TYPE_TIMESTAMP,
            255,
            ['default' => Table::TIMESTAMP_INIT],
            'Publish Date'
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Content'
        )->addColumn(
            'excerpt',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Excerpt'
        )->addColumn(
            'is_active',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 1],
            'Is Post Active'
        )->addColumn(
            'author_id',
            Table::TYPE_INTEGER,
            null,
            [],
            'Author ID'
        )->addColumn(
            'total_views',
            Table::TYPE_INTEGER,
            null,
            ['default' => 0],
            'Total Views'
        )->addColumn(
            'type',
            Table::TYPE_TEXT,
            255,
            [],
            'Type'
        )->addColumn(
            'og_title',
            Table::TYPE_TEXT,
            255,
            [],
            'OG Title'
        )->addColumn(
            'og_description',
            Table::TYPE_TEXT,
            '64M',
            [],
            'OG Description'
        )->addColumn(
            'og_img',
            Table::TYPE_TEXT,
            null,
            [],
            'OG IMG'
        )->addColumn(
            'og_type',
            Table::TYPE_TEXT,
            null,
            [],
            'OG Type'
        )->addColumn(
            'image',
            Table::TYPE_TEXT,
            255,
            [],
            'Image'
        )->addColumn(
            'meta_title',
            Table::TYPE_TEXT,
            null,
            [],
            'Meta Title'
        )->addColumn(
            'meta_keywords',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Keywords'
        )->addColumn(
            'meta_description',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Description'
        )->addColumn(
            'video_link',
            Table::TYPE_TEXT,
            255,
            [],
            'Video ID'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Post Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
            'Post Modification Time'
        )->addColumn(
            'allow_comment',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 1],
            'Allow Comment'
        )->addColumn(
            'page_layout',
            Table::TYPE_TEXT,
            255,
            ['default' => '2columns-right'],
            'Page Layout'
        )->addColumn(
            'featured',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 0],
            'Featured'
        )->addColumn(
            'pinned',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 0],
            'Pin post at the top'
        )->addIndex(
            $setup->getIdxName(
                $installer->getTable('mgz_blog_post'),
                ['title', 'identifier', 'content'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['title', 'identifier', 'content'],
            ['type' => AdapterInterface::INDEX_TYPE_FULLTEXT]
        )->setComment(
            'Blog Post Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_post_store'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_post_store')
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'store_id',
            Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Store ID'
        )->addIndex(
            $installer->getIdxName('mgz_blog_post_store', ['store_id']),
            ['store_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_store', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_store', 'store_id', 'store', 'store_id'),
            'store_id',
            $installer->getTable('store'),
            'store_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Post To Store Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        $customerGroupTable = $setup->getConnection()->describeTable($setup->getTable('customer_group'));
        $customerGroupIdType = $customerGroupTable['customer_group_id']['DATA_TYPE'] == 'int'
            ? Table::TYPE_INTEGER : $customerGroupTable['customer_group_id']['DATA_TYPE'];

        /**
         * Create table 'mgz_blog_post_customer_group'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_post_customer_group')
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'customer_group_id',
            $customerGroupIdType,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Customer Group ID'
        )->addIndex(
            $installer->getIdxName('mgz_blog_post_customer_group', ['customer_group_id']),
            ['customer_group_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_customer_group', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_customer_group', 'customer_group_id', 'customer_group', 'customer_group_id'),
            'customer_group_id',
            $installer->getTable('customer_group'),
            'customer_group_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Post To Customer Group Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_post_product'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_post_product')
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'product_id',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Store ID'
        )->addColumn(
            'position',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'default' => '0'],
            'Position'
        )->addIndex(
            $installer->getIdxName('mgz_blog_post_product', ['product_id']),
            ['product_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_product', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_product', 'product_id', 'catalog_product_entity', 'entity_id'),
            'product_id',
            $installer->getTable('catalog_product_entity'),
            'entity_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Post To Product Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_post_post'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_post_post')
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'position',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'default' => '0'],
            'Position'
        )->addIndex(
            $installer->getIdxName('mgz_blog_post_post', ['post_id']),
            ['post_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_post_post1', 'entity_id', 'mgz_blog_post', 'post_id'),
            'entity_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Post To Post Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_category'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_category')
        )->addColumn(
            'category_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Category ID'
        )->addColumn(
            'identifier',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Identifier'
        )->addColumn(
            'title',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Title'
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Content'
        )->addColumn(
            'is_active',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 1],
            'Is Category Active'
        )->addColumn(
            'parent_id',
            Table::TYPE_INTEGER,
            null,
            [],
            'Parent ID'
        )->addColumn(
            'include_in_menu',
            Table::TYPE_SMALLINT,
            null,
            [],
            'Include In Menu'
        )->addColumn(
            'position',
            Table::TYPE_TEXT,
            null,
            [],
            'Position'
        )->addColumn(
            'meta_title',
            Table::TYPE_TEXT,
            null,
            [],
            'Meta Title'
        )->addColumn(
            'meta_keywords',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Keywords'
        )->addColumn(
            'meta_description',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Description'
        )->addColumn(
            'list_layout',
            Table::TYPE_TEXT,
            255,
            [],
            'List Layout'
        )->addColumn(
            'page_layout',
            Table::TYPE_TEXT,
            255,
            ['default' => '2columns-right'],
            'Page Layout'
        )->addColumn(
            'grid_col',
            Table::TYPE_INTEGER,
            null,
            ['default' => 3],
            'Position'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Category Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
            'Category Modification Time'
        )->addIndex(
            $setup->getIdxName(
                $installer->getTable('mgz_blog_category'),
                ['title', 'identifier', 'content'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['title', 'identifier', 'content'],
            ['type' => AdapterInterface::INDEX_TYPE_FULLTEXT]
        )->setComment(
            'Blog Category Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_category_store'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_category_store')
        )->addColumn(
            'category_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Category ID'
        )->addColumn(
            'store_id',
            Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Store ID'
        )->addIndex(
            $installer->getIdxName('mgz_blog_category_store', ['store_id']),
            ['store_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_category_store', 'category_id', 'mgz_blog_category', 'category_id'),
            'category_id',
            $installer->getTable('mgz_blog_category'),
            'category_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_category_store', 'store_id', 'store', 'store_id'),
            'store_id',
            $installer->getTable('store'),
            'store_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Category To Store Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_category_post'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_category_post')
        )->addColumn(
            'category_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Category ID'
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'position',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'default' => '0'],
            'Position'
        )->addIndex(
            $installer->getIdxName('mgz_blog_category_post', ['post_id']),
            ['post_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_category_post', 'category_id', 'mgz_blog_category', 'category_id'),
            'category_id',
            $installer->getTable('mgz_blog_category'),
            'category_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_category_post', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Category To Store Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_author'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_author')
        )->addColumn(
            'author_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Author ID'
        )->addColumn(
            'identifier',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Identifier'
        )->addColumn(
            'first_name',
            Table::TYPE_TEXT,
            255,
            [],
            'First Name'
        )->addColumn(
            'last_name',
            Table::TYPE_TEXT,
            255,
            [],
            'Last Name'
        )->addColumn(
            'email',
            Table::TYPE_TEXT,
            255,
            [],
            'Email'
        )->addColumn(
            'nickname',
            Table::TYPE_TEXT,
            255,
            [],
            'Nickname'
        )->addColumn(
            'display_name',
            Table::TYPE_TEXT,
            255,
            [],
            'Display Name'
        )->addColumn(
            'image',
            Table::TYPE_TEXT,
            255,
            [],
            'Image'
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Content'
        )->addColumn(
            'short_content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Short Content'
        )->addColumn(
            'twitter',
            Table::TYPE_TEXT,
            255,
            [],
            'Twitter'
        )->addColumn(
            'facebook',
            Table::TYPE_TEXT,
            255,
            [],
            'Facebook'
        )->addColumn(
            'linkedin',
            Table::TYPE_TEXT,
            255,
            [],
            'Linkedin'
        )->addColumn(
            'flickr',
            Table::TYPE_TEXT,
            255,
            [],
            'Flickr'
        )->addColumn(
            'youtube',
            Table::TYPE_TEXT,
            255,
            [],
            'Youtube'
        )->addColumn(
            'pinterest',
            Table::TYPE_TEXT,
            255,
            [],
            'Pinterest'
        )->addColumn(
            'behance',
            Table::TYPE_TEXT,
            255,
            [],
            'Behance'
        )->addColumn(
            'instagram',
            Table::TYPE_TEXT,
            255,
            [],
            'Instagram'
        )->addColumn(
            'meta_title',
            Table::TYPE_TEXT,
            null,
            [],
            'Meta Title'
        )->addColumn(
            'meta_keywords',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Keywords'
        )->addColumn(
            'meta_description',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Description'
        )->addColumn(
            'user_id',
            Table::TYPE_INTEGER,
            null,
            [],
            'User ID'
        )->addColumn(
            'is_active',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 1],
            'Is Author Active'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Author Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
            'Author Modification Time'
        )->addIndex(
            $setup->getIdxName(
                $installer->getTable('mgz_blog_author'),
                ['identifier', 'content'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['identifier', 'content'],
            ['type' => AdapterInterface::INDEX_TYPE_FULLTEXT]
        )->setComment(
            'Blog Author Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_tag'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_tag')
        )->addColumn(
            'tag_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Tag ID'
        )->addColumn(
            'identifier',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Identifier'
        )->addColumn(
            'title',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Title'
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Content'
        )->addColumn(
            'is_active',
            Table::TYPE_SMALLINT,
            null,
            ['default' => 1],
            'Is Tag Active'
        )->addColumn(
            'meta_title',
            Table::TYPE_TEXT,
            null,
            [],
            'Meta Title'
        )->addColumn(
            'meta_keywords',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Keywords'
        )->addColumn(
            'meta_description',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Meta Description'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Tag Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
            'Tag Modification Time'
        )->addIndex(
            $setup->getIdxName(
                $installer->getTable('mgz_blog_tag'),
                ['title', 'identifier', 'content'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['title', 'identifier', 'content'],
            ['type' => AdapterInterface::INDEX_TYPE_FULLTEXT]
        )->setComment(
            'Blog Tag Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_tag_post'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_tag_post')
        )->addColumn(
            'tag_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Tag ID'
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addIndex(
            $installer->getIdxName('mgz_blog_tag_post', ['post_id']),
            ['post_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_tag_post', 'tag_id', 'mgz_blog_tag', 'tag_id'),
            'tag_id',
            $installer->getTable('mgz_blog_tag'),
            'tag_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_tag_post', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Tag To Post Linkage Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_comment'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mgz_blog_comment')
        )->addColumn(
            'comment_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'nullable' => false, 'primary' => true],
            'Comment ID'
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'primary' => true],
            'Post ID'
        )->addColumn(
            'parent_id',
            Table::TYPE_INTEGER,
            null,
            ['default' => 0],
            'Parent ID'
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '64M',
            [],
            'Content'
        )->addColumn(
            'author',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Author'
        )->addColumn(
            'author_email',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Author Email'
        )->addColumn(
            'customer_id',
            Table::TYPE_INTEGER,
            null,
            ['default' => 0],
            'Customer ID'
        )->addColumn(
            'store_id',
            Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Store ID'
        )->addColumn(
            'status',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Status'
        )->addColumn(
            'remote_ip',
            Table::TYPE_TEXT,
            255,
            [],
            'Remote Ip'
        )->addColumn(
            'brower',
            Table::TYPE_TEXT,
            255,
            [],
            'Brower'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Tag Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
            'Tag Modification Time'
        )->addIndex(
            $installer->getIdxName('mgz_blog_comment', ['store_id']),
            ['store_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_comment', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_comment', 'store_id', 'store', 'store_id'),
            'store_id',
            $installer->getTable('store'),
            'store_id',
            Table::ACTION_CASCADE
        )->setComment(
            'Blog Comment Table'
        );
        $installer->getConnection()->createTable($table);

        /**
         * Create table 'mgz_blog_viewed_post_index'
         * In MySQL version this table comes with unique keys to implement insertOnDuplicate(), so that
         * only one record is added when customer/visitor views same product again.
         */
        $table = $installer->getConnection()
        ->newTable($installer->getTable('mgz_blog_viewed_post_index'))
        ->addColumn(
            'index_id',
            Table::TYPE_BIGINT,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Index Id'
        )->addColumn(
            'visitor_id',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Visitor Id'
        )->addColumn(
            'customer_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => true],
            'Customer Id'
        )->addColumn(
            'post_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Post ID'
        )->addColumn(
            'store_id',
            Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true, 'nullable' => false],
            'Store ID'
        )->addColumn(
            'added_at',
            Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
            'Added At'
        )->addIndex(
            $installer->getIdxName(
                'mgz_blog_viewed_post_index',
                ['visitor_id', 'post_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['visitor_id', 'post_id'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addIndex(
            $installer->getIdxName('mgz_blog_viewed_post_index', ['store_id']),
            ['store_id']
        )->addIndex(
            $installer->getIdxName('mgz_blog_viewed_post_index', ['added_at']),
            ['added_at']
        )->addIndex(
            $installer->getIdxName('mgz_blog_viewed_post_index', ['post_id']),
            ['post_id']
        )->addForeignKey(
            $installer->getFkName('mgz_blog_viewed_post_index', 'post_id', 'mgz_blog_post', 'post_id'),
            'post_id',
            $installer->getTable('mgz_blog_post'),
            'post_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $installer->getFkName('mgz_blog_viewed_post_index2', 'store_id', 'store', 'store_id'),
            'store_id',
            $installer->getTable('store'),
            'store_id',
            Table::ACTION_CASCADE
        )->setComment('Reports Viewed Post Index Table');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}