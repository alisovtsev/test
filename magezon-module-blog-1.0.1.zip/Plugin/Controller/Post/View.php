<?php
/**
 * Magezon
 *
 * This source file is subject to the Magezon Software License, which is available at https://www.magezon.com/license
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to https://www.magezon.com for more information.
 *
 * @category  Magezon
 * @package   Magezon_Blog
 * @copyright Copyright (C) 2019 Magezon (https://www.magezon.com)
 */

namespace Magezon\Blog\Plugin\Controller\Post;

class View
{
	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \Magento\Customer\Model\Session
	 */
	protected $_customerSession;

	/**
	 * @var \Magento\Customer\Model\Visitor
	 */
	protected $_customerVisitor;

	/**
	 * @var \Magento\Framework\Registry
	 */
	protected $registry;

	/**
	 * @var \Magento\Framework\App\ResourceConnection
	 */
	protected $_resource;

	/**
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager    
	 * @param \Magento\Customer\Model\Session            $customerSession 
	 * @param \Magento\Customer\Model\Visitor            $customerVisitor 
	 * @param \Magento\Framework\Registry                $registry        
	 * @param \Magento\Framework\App\ResourceConnection  $resource        
	 */
	public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Model\Visitor $customerVisitor,
        \Magento\Framework\Registry $registry,
		\Magento\Framework\App\ResourceConnection $resource
	) {
		$this->_storeManager    = $storeManager;
		$this->_customerSession = $customerSession;
		$this->_customerVisitor = $customerVisitor;
		$this->registry         = $registry;
		$this->_resource        = $resource;
	}

	/**
	 * Logs the Product Name after product name is fetched.
	 *
	 * @param \Magento\Catalog\Model\Product $product
	 */
	public function afterExecute(
		$subject,
		$result
	) {
		$post = $this->registry->registry('current_post');
		if ($post) $this->reportViews($post);
		return $result;
	}

	/**
	 * @param  \Magezon\Blog\Model\Post $post
	 */
	public function reportViews($post)
	{
		$postId     = $post->getId();
		$visitorId  = $this->_customerVisitor->getId();
		$storeId    = $this->_storeManager->getStore()->getId();
		$customerId = $this->_customerSession->getId();
		$resource   = $this->_resource;
		$connection = $resource->getConnection();
		$table      = $resource->getTableName('mgz_blog_viewed_post_index');

		$select = $connection->select()
		->from($table)
		->where('post_id = ?', $postId)
		->where('visitor_id = ?', $visitorId)
		->where('store_id = ?', $storeId);

		$count = intval($connection->fetchOne($select));
		if (!$count) {
			$table = $table;
			$data  = [
				'post_id'     => (int)$postId,
				'visitor_id'  => (int)$visitorId,
				'store_id'    => (int)$storeId,
				'customer_id' => (int)$customerId
			];
			$insert = $resource->getConnection()->insert($table, $data);
			$totalViews = ((int)$post->getTotalViews()) + 1;
			$post->setTotalViews($totalViews);
			$post->save();
		}
	}
}